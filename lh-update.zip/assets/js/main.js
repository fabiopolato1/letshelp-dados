/* Let's Help | scripts do site */
(function(){
'use strict';
const CATS={"quasela": {"name": "Quase lá", "icon": "target", "tone": "t-o", "desc": "Vaquinhas que já passaram de 90% da meta. Falta pouco para fechar."}, "saude": {"name": "Saúde e tratamentos", "icon": "stethoscope", "tone": "t-o", "desc": "Tratamentos, cirurgias e remédios para quem não pode esperar."}, "animais": {"name": "Animais", "icon": "paw-print", "tone": "t-b", "desc": "Resgates, abrigos e tratamentos de cães, gatos e outros bichos."}, "fome": {"name": "Fome e alimentação", "icon": "soup", "tone": "t-c", "desc": "Marmitas, cestas básicas e comida na mesa de quem precisa."}, "criancas": {"name": "Crianças", "icon": "baby", "tone": "t-o", "desc": "Saúde, cuidado e oportunidades para os pequenos."}, "cancer": {"name": "Câncer", "icon": "ribbon", "tone": "t-b", "desc": "Apoio a quem enfrenta o tratamento contra o câncer."}, "emergencias": {"name": "Emergências e desastres", "icon": "siren", "tone": "t-c", "desc": "Enchentes, incêndios e tragédias que pedem ajuda rápida."}, "educacao": {"name": "Educação", "icon": "graduation-cap", "tone": "t-o", "desc": "Estudantes, escolas e projetos que abrem portas pelo conhecimento."}, "arte": {"name": "Arte e cultura", "icon": "palette", "tone": "t-b", "desc": "Música, teatro e cultura que fazem a cidade viver."}, "inclusao": {"name": "Inclusão e PcD", "icon": "accessibility", "tone": "t-c", "desc": "Acessibilidade, autonomia e respeito para pessoas com deficiência."}, "comunidades": {"name": "Comunidades e periferias", "icon": "users", "tone": "t-o", "desc": "Instituições e coletivos que cuidam do próprio território."}, "moradia": {"name": "Moradia", "icon": "house", "tone": "t-b", "desc": "Reconstruir, reformar ou conquistar um lar."}, "meioambiente": {"name": "Meio ambiente", "icon": "leaf", "tone": "t-c", "desc": "Natureza, clima e sustentabilidade na prática."}, "esporte": {"name": "Esporte", "icon": "trophy", "tone": "t-o", "desc": "Atletas e projetos que transformam vidas pelo esporte."}, "idosos": {"name": "Idosos", "icon": "hand-heart", "tone": "t-b", "desc": "Cuidado, dignidade e companhia para quem chegou lá."}, "sonhos": {"name": "Projetos e sonhos", "icon": "rocket", "tone": "t-c", "desc": "Projetos pessoais que merecem um empurrão."}};
const KEYS=Object.keys(CATS);
const PAGE=document.body.dataset.page||'home';
const reduceMotion=matchMedia('(prefers-reduced-motion: reduce)').matches;
const $=s=>document.querySelector(s);
const fmt=n=>'R$ '+Math.round(n).toLocaleString('pt-BR');
const HEART='<svg viewBox="0 0 100 92" fill="currentColor" aria-hidden="true"><use href="#heart"/></svg>';
function el(tag,cls,text){const e=document.createElement(tag); if(cls)e.className=cls; if(text!=null)e.textContent=text; return e;}
function icon(name){const i=document.createElement('i'); i.setAttribute('data-lucide',name); return i;}
function icons(){try{lucide.createIcons({attrs:{'stroke-width':2}})}catch(e){}}
/* ---------- Meta Pixel: eventos ---------- */
const track=(type,name,params)=>{ try{ if(typeof window.fbq==='function') window.fbq(type,name,params||{}); }catch(e){} };
const NEAR='quasela';
const pctOf=c=>c.goal>0?c.raised/c.goal:0;
const isNear=c=>!c.recurring&&c.goal>0&&pctOf(c)>=0.9&&pctOf(c)<1;
const inCat=(c,k)=>k===NEAR?(c.category===NEAR||isNear(c)):c.category===k;
const HOME_DEFAULT=KEYS.find(k=>k!==NEAR);

/* ---------- tema claro/escuro ---------- */
const themeBtn=$('#theme-btn');
function applyTheme(t){
  document.documentElement.setAttribute('data-theme',t);
  const m=document.querySelector('meta[name="theme-color"]'); if(m) m.content=t==='light'?'#FFF8F3':'#171528';
  if(themeBtn){ themeBtn.setAttribute('aria-label',t==='light'?'Mudar para o modo escuro':'Mudar para o modo claro'); themeBtn.setAttribute('aria-pressed',t==='light'?'true':'false'); }
}
applyTheme(document.documentElement.getAttribute('data-theme')==='light'?'light':'dark');
if(themeBtn) themeBtn.addEventListener('click',()=>{
  const t=document.documentElement.getAttribute('data-theme')==='light'?'dark':'light';
  document.documentElement.classList.add('theme-anim'); applyTheme(t); setTimeout(()=>document.documentElement.classList.remove('theme-anim'),450);
  try{localStorage.setItem('lh-theme',t);}catch(e){}
});

/* ---------- cabeçalho: sombra ao rolar ---------- */
const hdr=$('header');
const sentinel=document.createElement('div'); sentinel.style.cssText='position:absolute;top:0;height:1px;width:1px';
document.body.prepend(sentinel);
new IntersectionObserver(([e])=>hdr.classList.toggle('scrolled',!e.isIntersecting)).observe(sentinel);

/* ---------- mega menu (desktop) ---------- */
const megaBtn=$('#mega-btn'), mega=$('#mega'), megaLi=megaBtn&&megaBtn.closest('.has-mega');
let megaTimer;
function setMega(open){ if(!mega) return; mega.hidden=!open; megaBtn.setAttribute('aria-expanded',open?'true':'false'); megaLi.classList.toggle('open',open); }
if(megaBtn){
  megaBtn.addEventListener('click',e=>{e.stopPropagation(); setMega(mega.hidden);});
  megaLi.addEventListener('mouseenter',()=>{ if(matchMedia('(hover:hover)').matches){clearTimeout(megaTimer); setMega(true);} });
  megaLi.addEventListener('mouseleave',()=>{ if(matchMedia('(hover:hover)').matches){megaTimer=setTimeout(()=>setMega(false),160);} });
  document.addEventListener('click',e=>{ if(!megaLi.contains(e.target)) setMega(false); });
  document.addEventListener('keydown',e=>{ if(e.key==='Escape'&&!mega.hidden){setMega(false); megaBtn.focus();} });
  mega.addEventListener('click',e=>{ if(e.target.closest('a')) setMega(false); });
}

/* ---------- menu móvel ---------- */
const burger=$('#burger'), drawer=$('#drawer'), dbg=$('#drawer-bg'), dx=$('#drawer-x');
function setDrawer(open){
  drawer.hidden=!open; dbg.hidden=!open; burger.setAttribute('aria-expanded',open?'true':'false');
  document.documentElement.classList.toggle('lock',open);
  requestAnimationFrame(()=>drawer.classList.toggle('on',open));
  if(open) dx.focus(); else burger.focus();
}
if(burger){
  burger.addEventListener('click',()=>setDrawer(true));
  dx.addEventListener('click',()=>setDrawer(false));
  dbg.addEventListener('click',()=>setDrawer(false));
  drawer.addEventListener('click',e=>{ if(e.target.closest('a')) setDrawer(false); });
  document.addEventListener('keydown',e=>{ if(e.key==='Escape'&&!drawer.hidden) setDrawer(false); });
}

/* ---------- cards ---------- */
function progress(c){
  const pct=c.goal>0?Math.min(100,c.raised/c.goal*100):0;
  const done=c.goal>0&&c.raised>=c.goal;
  const pl=c.goal>0?(done?'Meta alcançada':(pct<0.5?'Começando agora':Math.min(99,Math.round(pct))+'%')):'';
  const m=el('div','meter'+(done?' is-done':'')); const bar=el('div','bar'); bar.setAttribute('role','progressbar'); bar.setAttribute('aria-valuemin','0'); bar.setAttribute('aria-valuemax','100'); bar.setAttribute('aria-valuenow',Math.round(pct)); bar.setAttribute('aria-label','Progresso médio das causas: '+Math.round(pct)+'% da meta'); bar.setAttribute('aria-label',(pl||'Sem meta')+' da meta');
  const fill=el('i'); fill.style.setProperty('--p',pct+'%'); bar.append(fill);
  const nums=el('div','nums'); const s=el('span'); s.append(el('b',null,fmt(c.raised)+(c.recurring?' por mês':''))); s.append(document.createTextNode(c.goal>0?(c.recurring?' meta de '+fmt(c.goal)+'/mês':' de '+fmt(c.goal)):' arrecadados'));
  nums.append(s, el('span',null,pl)); m.append(bar,nums); return m;
}
const isDone=c=>c.goal>0&&c.raised>=c.goal;
function reached(c){const m=el('span','reached'); m.append(icon('circle-check'), document.createTextNode(' Esta causa alcançou '+(c.raised>c.goal*1.005?Math.floor(c.raised/c.goal*100)+'% da':'a')+' meta'+(c.recurring?' do mês':'')+'.')); return m;}
function missing(c){const m=el('span','missing'); m.append(icon('target'), document.createTextNode(' Faltam '+fmt(c.goal-c.raised)+' para a meta')); return m;}
const hasPix=c=>/^\S+@\S+\.\S+$|^[0-9a-f-]{32,36}$|^\+?\d{10,14}$/i.test(c.pix||'');
function modeBadge(c){
  const p=hasPix(c); const m=el('span','mode '+(p?'mode-pix':'mode-plat'));
  m.title=p?'Copie a chave Pix oficial e doe pelo app do seu banco':'A doação é feita na página da campanha, com Pix, cartão ou boleto';
  m.append(icon(p?'zap':'external-link'), document.createTextNode(p?' Pix direto':' Doação pela plataforma')); return m;
}
function platDonateBtn(c,extra){
  if(!/^https:\/\//.test(c.url||'')) return null;
  const a=el('a','btn btn-primary plat-btn'+(extra?' '+extra:'')); a.href=c.url; a.target='_blank'; a.rel='noopener';
  a.append(el('span',null,'Doar na '+c.platform+' '), icon('arrow-up-right'));
  a.setAttribute('aria-label','Doar para "'+c.title+'" na '+c.platform+' (abre em nova aba)');
  a.addEventListener('click',()=>track('trackCustom','AbriuPlataforma',{causa:c.id,categoria:c.category,plataforma:c.platform,pagina:PAGE,acao:'doar'}));
  return a;
}
function platNote(){ return el('p','plat-note','Pix, cartão ou boleto direto na página da campanha.'); }
function pixRow(c){
  const r=el('div','pixk'); r.title='Chave Pix oficial da '+c.platform+' para esta causa';
  const l=el('span','pk-l'); l.append(icon('qr-code'), document.createTextNode(' Chave Pix'));
  r.append(l, el('code','pk-key',c.pix)); return r;
}
function pixDonateBtn(c,extra){
  const b=el('button','btn btn-primary pk-btn'+(extra?' '+extra:'')); b.type='button'; b.dataset.pix=c.pix; b.dataset.id=c.id; b.dataset.cat=c.category; b.dataset.plat=c.platform;
  b.setAttribute('aria-label','Doar agora com Pix para "'+c.title+'": copia a chave Pix '+c.pix);
  b.append(icon('copy'), el('span',null,'Doar agora com Pix')); return b;
}
async function copyText(t){ try{ await navigator.clipboard.writeText(t); return true; }catch(e){ const ta=document.createElement('textarea'); ta.value=t; ta.setAttribute('readonly',''); ta.style.cssText='position:fixed;opacity:0'; document.body.append(ta); ta.select(); let ok=false; try{ok=document.execCommand('copy');}catch(_){} ta.remove(); return ok; } }
let toastEl, toastT;
function toast(title,body){
  if(!toastEl){ toastEl=el('div','pix-toast'); toastEl.setAttribute('role','status'); toastEl.setAttribute('aria-live','polite'); document.body.append(toastEl); }
  const host=document.querySelector('dialog[open]')||document.body; if(toastEl.parentNode!==host) host.append(toastEl);
  toastEl.replaceChildren(el('strong',null,title), el('span',null,body));
  toastEl.classList.add('on'); clearTimeout(toastT); toastT=setTimeout(()=>toastEl.classList.remove('on'),6000);
}
document.addEventListener('click',async e=>{
  const b=e.target.closest('.pk-btn'); if(!b) return;
  const ok=await copyText(b.dataset.pix); const s=b.querySelector('span');
  b.classList.toggle('ok',ok); s.textContent=ok?'Chave Pix copiada!':'Copie a chave acima';
  if(ok) toast('Chave Pix copiada','Abra o app do seu banco, escolha Pix com chave e cole: '+b.dataset.pix);
  if(ok) track('trackCustom','PixCausaCopiado',{causa:b.dataset.id,categoria:b.dataset.cat,plataforma:b.dataset.plat,pagina:PAGE});
  clearTimeout(b._t); b._t=setTimeout(()=>{b.classList.remove('ok'); s.textContent='Doar agora com Pix';},3000);
});
/* ---------- compartilhar ---------- */
const SITE='https://letshelp.com.br';
function shareUrl(c,src){ return SITE+'/categoria/'+encodeURIComponent(c.category)+'?utm_source='+(src||'compartilhar')+'&utm_medium=social&utm_campaign=causa#c-'+encodeURIComponent(c.id); }
function shareText(c){ return 'Bora ajudar? '+c.title+(c.location?' ('+c.location+')':'')+'. '+(hasPix(c)?'Dá para doar direto pelo Pix oficial da campanha.':'Veja como doar na página da campanha.'); }
const XSVG='<svg viewBox="0 0 24 24" aria-hidden="true"><path fill="currentColor" d="M18.9 1.15h3.68l-8.04 9.19L24 22.85h-7.4l-5.8-7.58-6.63 7.58H.49l8.6-9.83L0 1.15h7.59l5.24 6.93zM17.61 20.64h2.04L6.49 3.24H4.3z"/></svg>';
const NETS=[
  ['whatsapp','WhatsApp','message-circle',(u,t)=>'https://wa.me/?text='+encodeURIComponent(t+' '+u)],
  ['facebook','Facebook','facebook',(u)=>'https://www.facebook.com/sharer/sharer.php?u='+encodeURIComponent(u)],
  ['x','X (Twitter)',null,(u,t)=>'https://twitter.com/intent/tweet?text='+encodeURIComponent(t)+'&url='+encodeURIComponent(u)],
  ['telegram','Telegram','send',(u,t)=>'https://t.me/share/url?url='+encodeURIComponent(u)+'&text='+encodeURIComponent(t)],
  ['linkedin','LinkedIn','linkedin',(u)=>'https://www.linkedin.com/sharing/share-offsite/?url='+encodeURIComponent(u)],
  ['instagram','Instagram','instagram',null],
  ['copiar','Copiar link','link',null]];
function shareBtn(c){
  const b=el('button','share-btn'); b.type='button'; b.dataset.share=c.id;
  b.setAttribute('aria-haspopup','menu'); b.setAttribute('aria-expanded','false');
  b.setAttribute('aria-label','Compartilhar "'+c.title+'" nas redes sociais');
  b.append(icon('share-2'), el('span',null,'Compartilhar')); return b;
}
let shareMenu=null, shareFor=null;
function closeShare(focus){ if(!shareMenu||shareMenu.hidden) return; shareMenu.hidden=true; if(shareFor){ shareFor.setAttribute('aria-expanded','false'); if(focus) shareFor.focus(); } shareFor=null; }
function openShare(b,c){
  if(!shareMenu){ shareMenu=el('div','share-menu'); shareMenu.setAttribute('role','menu'); shareMenu.hidden=true; document.body.append(shareMenu);
    shareMenu.addEventListener('keydown',e=>{ const items=[...shareMenu.querySelectorAll('[role=menuitem]')]; const i=items.indexOf(document.activeElement);
      if(e.key==='Escape'){e.preventDefault(); closeShare(true);} else if(e.key==='ArrowDown'){e.preventDefault(); items[(i+1)%items.length].focus();} else if(e.key==='ArrowUp'){e.preventDefault(); items[(i-1+items.length)%items.length].focus();} else if(e.key==='Tab') closeShare(false); }); }
  const host=b.closest('dialog[open]')||document.body; if(shareMenu.parentNode!==host) host.append(shareMenu);
  const t=shareText(c); const items=[el('p','share-h','Compartilhe esta causa')];
  NETS.forEach(([k,label,ic,fn])=>{
    const u=shareUrl(c,k==='copiar'?'link':k);
    const it=fn?el('a','share-it s-'+k):el('button','share-it s-'+k); it.setAttribute('role','menuitem');
    if(fn){ it.href=fn(u,t); it.target='_blank'; it.rel='noopener'; } else it.type='button';
    const dot=el('span','s-ic'); if(ic) dot.append(icon(ic)); else dot.insertAdjacentHTML('beforeend',XSVG);
    it.append(dot, el('span',null,label));
    it.addEventListener('click',async ev=>{
      track('trackCustom','CompartilhouCausa',{causa:c.id,categoria:c.category,rede:k,pagina:PAGE});
      if(!fn){ ev.preventDefault(); const ok=await copyText(k==='instagram'?t+' '+u:u);
        if(k==='instagram') toast(ok?'Texto e link copiados':'Copie o link', ok?'Abra o Instagram e cole nos Stories (figurinha de link) ou numa mensagem.':u);
        else toast(ok?'Link copiado':'Copie o link', ok?'Cole onde quiser compartilhar.':u); }
      closeShare(false);
    });
    items.push(it);
  });
  shareMenu.replaceChildren(...items); icons();
  shareMenu.hidden=false; shareFor=b; b.setAttribute('aria-expanded','true');
  const r=b.getBoundingClientRect(), mw=shareMenu.offsetWidth, mh=shareMenu.offsetHeight, fixed=host!==document.body;
  let x=Math.min(Math.max(12,r.right-mw), innerWidth-mw-12), y=r.bottom+8; if(y+mh>innerHeight-12) y=Math.max(12,r.top-mh-8);
  shareMenu.style.left=(x+(fixed?0:scrollX))+'px'; shareMenu.style.top=(y+(fixed?0:scrollY))+'px'; shareMenu.style.position=fixed?'fixed':'absolute';
  const f=shareMenu.querySelector('[role=menuitem]'); if(f) f.focus({preventScroll:true});
}
document.addEventListener('click',async e=>{
  const b=e.target.closest('.share-btn');
  if(!b){ if(shareMenu&&!shareMenu.hidden&&!e.target.closest('.share-menu')) closeShare(false); return; }
  const c=ALL.find(x=>x.id===b.dataset.share); if(!c) return;
  if(shareFor===b){ closeShare(true); return; }
  const coarse=matchMedia('(pointer:coarse)').matches;
  if(coarse&&navigator.share){ try{ await navigator.share({title:c.title,text:shareText(c),url:shareUrl(c,'nativo')}); track('trackCustom','CompartilhouCausa',{causa:c.id,categoria:c.category,rede:'nativo',pagina:PAGE}); return; }catch(err){ if(err&&err.name==='AbortError') return; } }
  closeShare(false); openShare(b,c);
});
addEventListener('resize',()=>closeShare(false));
function supporters(c){const sp=el('span','supporters'); sp.insertAdjacentHTML('beforeend',HEART); sp.append(document.createTextNode((c.supporters||0).toLocaleString('pt-BR')+(c.recurring?' apoiadores mensais':' apoiadores'))); return sp;}
function donate(c,cls){ if(!/^https:\/\//.test(c.url||'')) return null; const go=el('a',cls,'Ver na '+c.platform+' '); go.href=c.url; go.target='_blank'; go.rel='noopener'; go.addEventListener('click',()=>track('trackCustom','AbriuPlataforma',{causa:c.id,categoria:c.category,plataforma:c.platform,pagina:PAGE})); go.append(icon('arrow-up-right')); go.setAttribute('aria-label','Ver "'+c.title+'" na '+c.platform+' (abre em nova aba)'); return go; }
function thumb(c,h){
  if(!/^https:\/\//.test(c.image||'')) return;
  const im=document.createElement('img'); im.className='thumb'; im.alt=''; im.loading='lazy'; im.decoding='async'; im.referrerPolicy='no-referrer'; im.src=c.image;
  im.addEventListener('load',()=>h.classList.add('has-img')); im.addEventListener('error',()=>im.remove()); h.append(im);
}
function card(c,opts){
  opts=opts||{};
  const meta=CATS[c.category]||{name:'Causa',icon:'heart',tone:'t-c'};
  const a=el('article','cause'+(c.featured&&opts.badge!==false?' feat':''));
  a.id='c-'+c.id;
  const h=el('div','chead '+meta.tone);
  h.insertAdjacentHTML('beforeend','<svg class="bgheart" viewBox="0 0 100 92" aria-hidden="true"><use href="#heart"/></svg>');
  const bi=el('span','bigic'); bi.append(icon(meta.icon)); h.append(bi); thumb(c,h);
  const chips=el('div','chips-in'); const tag=el('a','tag',meta.name); tag.href='/categoria/'+c.category; chips.append(tag, el('span','plat',c.platform)); h.append(chips);
  a.append(h);
  const b=el('div','body');
  if(c.featured&&opts.badge!==false){const bd=el('span','badge'); bd.insertAdjacentHTML('beforeend',HEART); bd.append(document.createTextNode('Destaque em '+meta.name)); b.append(bd);}
  b.append(modeBadge(c), el('h3',null,c.title), el('span','org',[c.organizer,c.location].filter(Boolean).join(', ')), el('p','desc',c.description), progress(c));
  if(isNear(c)) b.append(missing(c)); else if(isDone(c)) b.append(reached(c));
  const f=el('div','foot'); f.append(supporters(c)); const fr=el('div','foot-r'); fr.append(shareBtn(c));
  if(hasPix(c)){ b.append(pixRow(c), pixDonateBtn(c,'pk-full')); const d=donate(c,'go'); if(d) fr.append(d); }
  else { const pb=platDonateBtn(c,'pk-full'); if(pb) b.append(pb, platNote()); }
  f.append(fr);
  b.append(f);
  a.append(b); return a;
}
function spotCard(c,label){
  const meta=CATS[c.category]||{name:'Causa',icon:'heart',tone:'t-c'};
  const a=el('article','spot '+meta.tone);
  if(!document.getElementById('c-'+c.id)) a.id='c-'+c.id;
  const media=el('div','spot-media chead '+meta.tone);
  media.insertAdjacentHTML('beforeend','<svg class="bgheart" viewBox="0 0 100 92" aria-hidden="true"><use href="#heart"/></svg>');
  const bi=el('span','bigic'); bi.append(icon(meta.icon)); media.append(bi); thumb(c,media);
  a.append(media);
  const b=el('div','spot-body');
  const top=el('div','spot-tags'); const tg=el('a','tag',meta.name); tg.href='/categoria/'+c.category; top.append(el('span','badge',label||'Em destaque'), tg, el('span','plat',c.platform), modeBadge(c)); b.append(top);
  b.append(el('h3','spot-title',c.title), el('span','org',[c.organizer,c.location].filter(Boolean).join(', ')), el('p','desc',c.description), progress(c));
  if(isNear(c)) b.append(missing(c)); else if(isDone(c)) b.append(reached(c));
  const f=el('div','spot-actions');
  if(hasPix(c)){ b.append(pixRow(c)); f.append(pixDonateBtn(c)); } else { const pb=platDonateBtn(c); if(pb) f.append(pb); }
  if(PAGE==='home'){const more=el('a','btn btn-ghost','Mais de '+meta.name); more.href='/categoria/'+c.category; f.append(more);}
  const sf=el('div','foot spot-foot'); sf.append(supporters(c)); const sr=el('div','foot-r'); sr.append(shareBtn(c)); if(hasPix(c)){ const d=donate(c,'go'); if(d) sr.append(d); } sf.append(sr); if(!hasPix(c)) sf.append(el('span','plat-note','Pix, cartão ou boleto na página da campanha'));
  b.append(f, sf); a.append(b); return a;
}
function pop(list){ list.forEach((c,i)=>{c.style.setProperty('--d',(Math.min(i,8)*60)+'ms'); c.classList.add('pop');}); }

/* ---------- dados ---------- */
const SOURCES=['https://raw.githubusercontent.com/fabiopolato1/letshelp-dados/main/causes.json','/data/causes.json'];
const valid=j=>j&&Array.isArray(j.causes)&&j.causes.length>0;
async function tryFetch(url){
  const ctl=new AbortController(); const t=setTimeout(()=>ctl.abort(),5000);
  try{const r=await fetch(url+(url.includes('?')?'&':'?')+'t='+Date.now(),{cache:'no-store',signal:ctl.signal}); if(!r.ok) throw 0; const j=await r.json(); if(!valid(j)) throw 0; return j;}
  finally{clearTimeout(t);}
}
async function loadCauses(){
  for(const u of SOURCES){ try{ return await tryFetch(u); }catch(e){} }
  throw new Error('sem dados');
}
function counts(data){
  const n={};
  KEYS.forEach(k=>n[k]=data.causes.filter(c=>inCat(c,k)).length);
  document.querySelectorAll('[data-cnt]').forEach(s=>{const v=n[s.dataset.cnt]; if(v==null) return; s.textContent=s.classList.contains('cc')?String(v):(v===1?'1 causa':v+' causas');});
}
function showUpdated(data){
  const u=$('#updated'); if(!u||!data.updated) return;
  const d=new Date(data.updated+'T12:00:00'); u.querySelector('span').textContent='Atualizado em '+d.toLocaleDateString('pt-BR',{day:'numeric',month:'long',year:'numeric'}); u.hidden=false;
}
function sortCat(list,k){ if(k===NEAR) return list.slice().sort((x,y)=>pctOf(y)-pctOf(x)); return list.slice().sort((x,y)=>((y.featured&&y.category===k)-(x.featured&&x.category===k))||((y.category===k)-(x.category===k))||(hasPix(y)-hasPix(x))||(y.supporters-x.supporters)); }

/* ---------- barra de filtros ---------- */
const chips=$('#chips'), chipbar=$('#chipbar');
function setChip(k){
  if(!chips) return;
  chips.querySelectorAll('.chip').forEach(b=>{const on=b.dataset.cat===k; b.setAttribute('aria-pressed',on?'true':'false'); if(on){ const r=b.getBoundingClientRect(), cr=chips.getBoundingClientRect(); if(r.left<cr.left||r.right>cr.right) chips.scrollTo({left:b.offsetLeft-cr.width/2+r.width/2,behavior:reduceMotion?'auto':'smooth'}); }});
}
function headerH(){ return hdr.getBoundingClientRect().height; }
/* garante que os cards apareçam logo abaixo da barra de filtros, sem o usuário rolar */
function bringResults(){
  if(!chipbar) return;
  const top=chipbar.getBoundingClientRect().top+scrollY-headerH();
  const cur=chipbar.getBoundingClientRect().top-headerH();
  if(Math.abs(cur)>4) window.scrollTo({top,behavior:reduceMotion?'auto':'smooth'});
}

/* ---------- home ---------- */
function home(data){
  const grid=$('#grid'), rh=$('#results-head'), rf=$('#results-foot'), spot=$('#spot');
  const feats=data.causes.filter(c=>c.featured);
  let last=-1;
  function showSpot(){
    if(!feats.length){spot.closest('section').hidden=true; return;}
    let i; do{ i=Math.floor(Math.random()*feats.length); }while(feats.length>1&&i===last); last=i;
    const node=spotCard(feats[i],'Em destaque agora'); spot.replaceChildren(node); if(!reduceMotion) node.classList.add('pop'); icons();
  }
  showSpot();
  const nx=$('#spot-next'); if(nx) nx.addEventListener('click',showSpot);

  function render(k,scroll){
    if(!CATS[k]) k=HOME_DEFAULT;
    const list=sortCat(data.causes.filter(c=>inCat(c,k)),k), title=CATS[k].name, sub=list.length+(list.length===1?' causa':' causas')+' nesta categoria';
    rh.replaceChildren(el('h3',null,title), el('span',null,sub));
    if(list.length){ const cards=list.map(c=>card(c,{badge:false})); grid.replaceChildren(...cards); pop(cards); }
    else { const e=el('div','empty'); e.append(el('h3',null,'Ainda não tem causa aqui'), el('p',null,'As causas mudam toda semana. Volte em breve ou escolha outro tema.')); grid.replaceChildren(e); }
    rf.replaceChildren();
    { const a=el('a','btn btn-ghost','Abrir a página de '+CATS[k].name+' '); a.href='/categoria/'+k; a.append(icon('arrow-right')); rf.append(a); }
    setChip(k); icons();
    if(scroll) bringResults();
  }
  if(chips) chips.addEventListener('click',e=>{const b=e.target.closest('.chip'); if(!b) return; render(b.dataset.cat,true);});
  render(HOME_DEFAULT,false);
  nearCarousel(data);
}

/* ---------- carrossel Quase lá ---------- */
function nearCarousel(data){
  const sec=$('#quase-la'), track=$('#near-track'); if(!track) return;
  const list=sortCat(data.causes.filter(c=>inCat(c,NEAR)),NEAR);
  if(!list.length){ sec.hidden=true; return; }
  const cards=list.map(c=>card(c,{badge:false})); track.replaceChildren(...cards); icons();
  const prev=$('#near-prev'), next=$('#near-next');
  const step=()=>{const c=track.firstElementChild; const gap=parseFloat(getComputedStyle(track).columnGap)||0; return c?(c.getBoundingClientRect().width+gap)*Math.max(1,Math.floor((track.clientWidth+gap)/(c.getBoundingClientRect().width+gap))):track.clientWidth;};
  const upd=()=>{ prev.disabled=track.scrollLeft<4; next.disabled=track.scrollLeft+track.clientWidth>=track.scrollWidth-4; sec.querySelector('.car-nav').hidden=track.scrollWidth<=track.clientWidth+4; };
  prev.addEventListener('click',()=>track.scrollBy({left:-step(),behavior:reduceMotion?'auto':'smooth'}));
  next.addEventListener('click',()=>track.scrollBy({left:step(),behavior:reduceMotion?'auto':'smooth'}));
  track.addEventListener('scroll',()=>requestAnimationFrame(upd),{passive:true}); addEventListener('resize',upd); upd();
  track.addEventListener('keydown',e=>{ if(e.key==='ArrowRight'){e.preventDefault(); next.click();} if(e.key==='ArrowLeft'){e.preventDefault(); prev.click();} });
}

/* ---------- página de categoria ---------- */
function categoria(data){
  const m=location.pathname.match(/\/categoria\/([a-z]+)/)||location.search.match(/[?&]c=([a-z]+)/);
  const k=m&&m[1];
  const grid=$('#grid'), rh=$('#results-head'), spot=$('#spot');
  if(chips){
    chips.querySelectorAll('.chip').forEach(b=>{ const a=document.createElement('a'); a.className=b.className; a.innerHTML=b.innerHTML; const ck=b.dataset.cat; a.href='/categoria/'+ck; if(ck===k) a.setAttribute('aria-current','page'); a.dataset.cat=ck; b.replaceWith(a); });
    const cur=chips.querySelector('[aria-current]'); if(cur) requestAnimationFrame(()=>chips.scrollLeft=cur.offsetLeft-chips.clientWidth/2+cur.clientWidth/2);
  }
  if(!k||!CATS[k]){
    document.title="Categoria não encontrada | Let's Help";
    $('#cat-title').textContent='Categoria não encontrada'; $('#cat-desc').textContent='Escolha um dos temas abaixo para ver as causas.'; $('#crumb-cat').textContent='Não encontrada';
    grid.replaceChildren(); spot.replaceChildren(); return;
  }
  const meta=CATS[k];
  track('track','ViewContent',{content_category:k,content_name:meta.name,content_type:'categoria'});
  document.title=meta.name+" | Let's Help";
  const md=document.querySelector('meta[name="description"]'); if(md) md.content='Vaquinhas verificadas de '+meta.name.toLowerCase()+'. '+meta.desc;
  const can=document.querySelector('link[rel="canonical"]'); if(can) can.href='https://letshelp.com.br/categoria/'+k;
  $('#cat-hero').classList.add(meta.tone);
  $('#cat-title').textContent=meta.name; $('#cat-desc').textContent=meta.desc; $('#crumb-cat').textContent=meta.name;
  const ic=$('#cat-icon'); ic.replaceChildren(icon(meta.icon));
  document.querySelectorAll('[data-catlink="'+k+'"]').forEach(a=>a.setAttribute('aria-current','page'));
  const list=sortCat(data.causes.filter(c=>inCat(c,k)),k);
  rh.replaceChildren(el('h2',null,list.length+(list.length===1?' causa':' causas')+' esta semana'), el('span',null,'Pix direto com a chave oficial ou doação na página da plataforma'));
  if(!list.length){ spot.replaceChildren(); const e=el('div','empty'); e.append(el('h3',null,'Ainda não tem causa aqui'), el('p',null,'As causas mudam toda semana. Volte em breve.')); grid.replaceChildren(e); icons(); return; }
  const first=list[0]; const node=spotCard(first,k===NEAR?'Mais perto da meta':(first.featured&&first.category===k?'Destaque da categoria':'Em destaque')); spot.replaceChildren(node);
  const cards=list.slice(1).map(c=>card(c,{badge:false})); grid.replaceChildren(...cards); pop(cards);
  icons();
}

/* ---------- copiar texto (e-mail de contato) ---------- */
document.addEventListener('click',async e=>{
  const b=e.target.closest('[data-copy]'); if(!b) return;
  const ok=await copyText(b.dataset.copy);
  toast(ok?'E-mail copiado':'Copie o e-mail', ok?'Cole no seu e-mail: '+b.dataset.copy:b.dataset.copy);
  b.classList.toggle('ok',ok); clearTimeout(b._t); b._t=setTimeout(()=>b.classList.remove('ok'),2500);
  if(ok) track('trackCustom','EmailCopiado',{pagina:PAGE});
});

/* ---------- doe para uma causa aleatória (pop-up) ---------- */
let ALL=[], randLast=null, randPending=false;
const dlg=$('#rand-dlg');
function randPick(){
  if(!ALL.length) return null;
  let c; do{ c=ALL[Math.floor(Math.random()*ALL.length)]; }while(ALL.length>1&&c===randLast);
  randLast=c; return c;
}
function randRender(c){
  const meta=CATS[c.category]||{name:'Causa',icon:'heart',tone:'t-c'};
  const box=el('div','rand-in');
  const media=el('div','rand-media chead '+meta.tone);
  media.insertAdjacentHTML('beforeend','<svg class="bgheart" viewBox="0 0 100 92" aria-hidden="true"><use href="#heart"/></svg>');
  const bi=el('span','bigic'); bi.append(icon(meta.icon)); media.append(bi); thumb(c,media);
  const x=el('button','rand-x'); x.type='button'; x.setAttribute('aria-label','Fechar'); x.append(icon('x')); x.addEventListener('click',()=>dlg.close());
  media.append(x);
  const body=el('div','rand-body');
  const tags=el('div','spot-tags rand-tags'); const tg=el('a','tag',meta.name); tg.href='/categoria/'+c.category; tags.append(modeBadge(c), tg, el('span','plat',c.platform));
  const h=el('h2','rand-title',c.title); h.id='rand-title';
  body.append(el('span','rand-kicker','Causa sorteada para você'), tags, h, el('span','org',[c.organizer,c.location].filter(Boolean).join(', ')), el('p','desc',c.description), progress(c));
  if(isNear(c)) body.append(missing(c)); else if(isDone(c)) body.append(reached(c));
  if(hasPix(c)) body.append(pixRow(c), pixDonateBtn(c,'pk-full'));
  else { const pb=platDonateBtn(c,'pk-full'); if(pb) body.append(pb, platNote()); }
  const more=el('div','rand-more');
  const again=el('button','btn btn-ghost'); again.type='button'; again.append(icon('shuffle'), el('span',null,' Sortear outra')); again.addEventListener('click',()=>openRandom(true));
  const see=el('a','rand-link','Ver todas de '+meta.name+' '); see.href='/categoria/'+c.category; see.append(icon('arrow-right'));
  more.append(again, see);
  const links=el('div','rand-links');
  if(/^https:\/\//.test(c.url||'')){ const camp=el('a',null,'Página da campanha na '+c.platform+' '); camp.href=c.url; camp.target='_blank'; camp.rel='noopener'; camp.append(icon('arrow-up-right')); camp.addEventListener('click',()=>track('trackCustom','AbriuPlataforma',{causa:c.id,categoria:c.category,plataforma:c.platform,pagina:PAGE,acao:'popup'})); links.append(camp); }
  const homeL=el('a',null,'Página inicial do Let\'s Help'); homeL.href='/'; links.append(homeL);
  body.append(more, supporters(c), links);
  box.append(media, body);
  dlg.replaceChildren(box); icons();
}
function openRandom(again,forced){
  if(!dlg) return;
  if(!ALL.length){ randPending=true; return; }
  const c=forced||randPick(); if(!c) return; if(forced) randLast=c;
  randRender(c);
  if(!dlg.open){ dlg.showModal(); document.documentElement.classList.add('lock'); }
  dlg.scrollTop=0;
  track('trackCustom','SorteioCausa',{causa:c.id,categoria:c.category,plataforma:c.platform,pix:hasPix(c)?'sim':'nao',novo_sorteio:again?'sim':'nao',pagina:PAGE});
}
if(dlg){
  dlg.addEventListener('close',()=>document.documentElement.classList.remove('lock'));
  dlg.addEventListener('click',e=>{ if(e.target===dlg) dlg.close(); });
}
document.addEventListener('click',e=>{ const b=e.target.closest('[data-random]'); if(!b) return; e.preventDefault(); openRandom(false); });

/* ---------- painel da primeira dobra: slideshow + lista de causas ---------- */
function livePanel(data){
  const card=$('#live'); if(!card) return;
  const list=data.causes.filter(c=>c.goal>0);
  const show=$('#live-show'), dots=$('#live-dots'), feed=$('#live-feed'), note=$('#live-note');
  if(data.updated&&note){ const d=new Date(data.updated+'T12:00:00'); note.textContent='Dados das plataformas em '+d.toLocaleDateString('pt-BR',{day:'numeric',month:'long'})+'.'; }
  // slideshow de fotos das causas da semana
  const pics=data.causes.filter(c=>/^https:\/\//.test(c.image||'')).sort(()=>Math.random()-.5).slice(0,8);
  if(show&&pics.length){
    let cur=0; const slides=[], ds=[];
    pics.forEach((c,k)=>{
      const meta=CATS[c.category]||{name:'Causa'};
      const s=el('button','live-slide'+(k===0?' on':'')); s.type='button'; s.setAttribute('aria-label','Ver a causa '+c.title); if(k) s.tabIndex=-1;
      const im=document.createElement('img'); im.alt=''; im.decoding='async'; im.referrerPolicy='no-referrer'; im.loading=k<2?'eager':'lazy'; im.src=c.image;
      im.addEventListener('error',()=>s.classList.add('noimg'));
      const cap=el('span','live-cap'); cap.append(el('span','live-cat',meta.name), el('b',null,c.title));
      s.append(im,cap); s.addEventListener('click',()=>openRandom(false,c)); show.append(s); slides.push(s);
      const d=el('button','live-d'+(k===0?' on':'')); d.type='button'; d.setAttribute('aria-label','Foto '+(k+1)+' de '+pics.length); d.addEventListener('click',()=>{go(k);restart();}); dots.append(d); ds.push(d);
    });
    const go=k=>{ slides[cur].classList.remove('on'); slides[cur].tabIndex=-1; ds[cur].classList.remove('on'); cur=(k+pics.length)%pics.length; slides[cur].classList.add('on'); slides[cur].tabIndex=0; ds[cur].classList.add('on'); };
    let t=null; const start=()=>{ if(!reduceMotion&&pics.length>1) t=setInterval(()=>go(cur+1),3800); }, restart=()=>{ clearInterval(t); start(); };
    start();
    show.addEventListener('mouseenter',()=>clearInterval(t)); show.addEventListener('mouseleave',restart);
    document.addEventListener('visibilitychange',()=>{ clearInterval(t); if(!document.hidden) start(); });
  } else if(show){ show.hidden=true; dots.hidden=true; }
  // lista que vai mostrando causas reais com a barra de progresso
  const pool=list.slice().sort(()=>Math.random()-.5); let i=0;
  const item=c=>{
    const meta=CATS[c.category]||{name:'Causa',icon:'heart',tone:'t-c'};
    const li=el('li','live-item'); const b=el('button','live-btn'); b.type='button'; b.setAttribute('aria-label','Ver a causa '+c.title);
    const ic=el('span','live-ic '+meta.tone); ic.append(icon(meta.icon));
    const tx=el('span','live-tx'); tx.append(el('b',null,c.title), el('span',null,isDone(c)?'Meta alcançada':Math.min(99,Math.round(pctOf(c)*100))+'% da meta'));
    const mb=el('span','live-mini'+(isDone(c)?' is-done':'')); const mi=el('i'); mb.append(mi);
    b.append(ic,tx,mb); b.addEventListener('click',()=>openRandom(false,c)); li.append(b);
    requestAnimationFrame(()=>requestAnimationFrame(()=>{ li.classList.add('in'); mi.style.width=Math.min(100,pctOf(c)*100)+'%'; }));
    return li;
  };
  const push=()=>{ const c=pool[i++%pool.length]; feed.prepend(item(c)); icons(); const items=feed.querySelectorAll('.live-item'); for(let k=3;k<items.length;k++) items[k].remove(); };
  push(); push(); push();
  if(!reduceMotion){ let timer=setInterval(push,2800); document.addEventListener('visibilitychange',()=>{ clearInterval(timer); if(!document.hidden) timer=setInterval(push,2800); }); }
}

/* ---------- menu: página atual ---------- */
document.querySelectorAll('[data-navlink="'+PAGE+'"]').forEach(a=>a.setAttribute('aria-current','page'));

/* ---------- carregar ---------- */
loadCauses().then(data=>{
  data.causes=data.causes.filter(c=>/^https:\/\//.test(c.url||''));
  ALL=data.causes; if(randPending){ randPending=false; openRandom(false); }
  counts(data); showUpdated(data);
  if(PAGE==='home'){ home(data); livePanel(data); } else if(PAGE==='categoria') categoria(data);
  if(location.hash.length>1){const t=document.getElementById(decodeURIComponent(location.hash.slice(1))); if(t) requestAnimationFrame(()=>t.scrollIntoView());}
}).catch(()=>{
  const g=$('#grid'); if(!g) return; const e=el('div','empty'); e.append(el('h3',null,'Não conseguimos carregar as causas'), el('p',null,'Atualize a página em alguns instantes.')); g.replaceChildren(e); const s=$('#spot'); if(s) s.replaceChildren();
});
icons();

/* ---------- Pix ---------- */
const pixIn=$('#pix-code'), pixBtn=$('#pix-copy');
if(pixBtn) pixBtn.addEventListener('click',async()=>{
  track('trackCustom','PixLetsHelpCopiado',{pagina:PAGE});
  const lbl=pixBtn.lastChild;
  try{ await navigator.clipboard.writeText(pixIn.value); }catch(e){ pixIn.select(); try{document.execCommand('copy');}catch(_){} }
  pixBtn.classList.add('ok'); lbl.textContent=' Código copiado'; setTimeout(()=>{pixBtn.classList.remove('ok'); lbl.textContent=' Copiar código';},2500);
});
if(pixIn) pixIn.addEventListener('focus',()=>pixIn.select());
function drawQR(){
  const box=$('#pix-qr'); if(!box||!pixIn) return;
  if(typeof qrcode!=='function'){ box.closest('figure').hidden=true; return; }
  const q=qrcode(0,'M'); q.addData(pixIn.value); q.make();
  box.innerHTML=q.createSvgTag({cellSize:5,margin:2,scalable:true});
}
if(document.readyState==='complete') drawQR(); else addEventListener('load',drawQR);

/* ---------- animações de entrada ---------- */
const revealEls=[...document.querySelectorAll('[data-reveal]')];
if('IntersectionObserver' in window && !reduceMotion){
  document.documentElement.classList.add('js-reveal');
  const show=t=>{const i=revealEls.indexOf(t); for(let k=0;k<=i;k++){ if(!revealEls[k].classList.contains('in')){ revealEls[k].classList.add('in'); io.unobserve(revealEls[k]); } }};
  const io=new IntersectionObserver(es=>es.forEach(e=>{ if(e.isIntersecting||e.boundingClientRect.top<0) show(e.target); }),{rootMargin:'0px 0px -6% 0px',threshold:0});
  revealEls.forEach(x=>io.observe(x));
}
})();
